"""
Could add/update context variables here, but they do not have access to any Python code
"""
