# note -- this file is not used when building with pyproject.toml
from setuptools import setup

if __name__ == '__main__':
    setup()


