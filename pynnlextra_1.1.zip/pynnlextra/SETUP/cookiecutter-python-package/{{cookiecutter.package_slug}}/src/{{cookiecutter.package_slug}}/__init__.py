# this is the init module for {{cookiecutter.package_slug}}
# Things to put here:
# 1. package docstring
# 2. code that will be avaiable via the package name
# 3. "convenience imports" -- imports of names from subpackages and submodules