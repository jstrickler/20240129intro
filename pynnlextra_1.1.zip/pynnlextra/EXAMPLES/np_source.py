import numpy as np
import scipy.fftpack as ff


def main():
    np.source(ff.fft)


if __name__ == '__main__':
    main()
